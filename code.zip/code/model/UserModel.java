package model;

public class UserModel extends GenericModel{
    
}
