package model;

public class AdministradorModel extends GenericModel{
    
}
