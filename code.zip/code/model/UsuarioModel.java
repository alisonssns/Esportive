package model;

public class UsuarioModel extends GenericModel{
    
}
