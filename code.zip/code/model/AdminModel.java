package model;

public class AdminModel extends GenericModel{
    
}
