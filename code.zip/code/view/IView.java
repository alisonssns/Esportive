package view;

public interface IView {
    void exibirMenuInicial();
    void exibirMenuPrincipal();
}
